import UIKit

class ListMovieViewControllerViewModel: UIViewController {

 var a = 10

}
