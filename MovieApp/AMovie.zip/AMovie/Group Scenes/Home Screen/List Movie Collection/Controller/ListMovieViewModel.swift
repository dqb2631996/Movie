
import Foundation
final class ListMovieViewModel {
    var discoverMovieResponse: DiscoverMovieResponse?
    private var pageNumber = 1
    private var isLoading = false
    private var countSearch = 0
    var sortType: SortType = .popularity
    var reloadTableView: (() -> ())?
    
    func fetchMoviesData() {
        pageNumber = 1
        print(1)
        print(self.discoverMovieResponse?.results.count)
        NetworkManager.shared.getMovieData(page: pageNumber, sortType: sortType) { discoverMovie in
            self.discoverMovieResponse = discoverMovie
            print(discoverMovie.results.count)
            self.reloadTableView?()
            print(2)
        }
        print(3)
    }
    
    func loadMoreData() {
        pageNumber += 1
        if !isLoading {
            isLoading = true
            NetworkManager.shared.getMovieData(page: pageNumber, sortType: sortType) { discoverMovie in
                self.discoverMovieResponse?.results += discoverMovie.results
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    self.isLoading = false
                }
            }
        }
    }
    
    func getNumberOfRows(_ section: Int) -> Int {
        if discoverMovieResponse?.results.count != 0 {
            return discoverMovieResponse?.results.count ?? 0
        }
        return 0
    }
    
    func getCellForRow (_ indexPath: IndexPath) -> Movie {
        return (discoverMovieResponse?.results[indexPath.row])!
    }
    
    func countRow(_ indexPath: IndexPath) -> Int {
        return  discoverMovieResponse?.results.count ?? 0
    }
    
    func changeSortType(index: Int) {
        sortType = SortType.allCases[index]
    }
}
