//
//  SortMovieCollectionViewCell.swift
//  AMovie
//
//  Created by Mac on 2/18/22.
//  Copyright © 2022 identifier.demo.1. All rights reserved.
//

import UIKit

class SortMovieCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var sortLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
