import Foundation

struct APIKey {
    static let apiKey: String = "328c283cd27bd1877d9080ccb1604c91"
}
