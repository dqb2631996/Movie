import Foundation
import UIKit

//extension UIImageView {
//    func getImageFromUrl(url: String) {
//        if let url = URL(string: URLs.imageBaseURL + url) {
//            DispatchQueue.main.async {
//                if let data = try? Data(contentsOf: url) {
//                    self.image = UIImage(data: data)
//                } else {
//                    self.image = UIImage()
//                    self.backgroundColor = .purple
//                }
//            }
//        }
//    }
//}

extension UIImageView {

    func getImageFromUrl(url: String, _ placeHolder: UIImage? = nil) {
        guard let url = URL(string: URLs.imageBaseURL + url) else {
            image = placeHolder
            return
        }
        DispatchQueue.global(qos: .background).async {
            guard let data = try? Data(contentsOf: url) else {
                DispatchQueue.main.async {
                    self.image = placeHolder
                }
                return
            }
            DispatchQueue.main.async {
                self.image = UIImage(data: data)
                self.backgroundColor = .gray
            }
        }
    }
}



